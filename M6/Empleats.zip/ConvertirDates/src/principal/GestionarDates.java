package principal;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GestionarDates {

	public static void main(String[] args) throws ParseException {

						
			//java.sql.Date valueOf nom�s admet String en format yyyy-mm-dd
			//si posem un altre format dona error
			String dataString1 = "2023-12-31";
			java.sql.Date dateSQLDate = java.sql.Date.valueOf(dataString1);
			System.out.println(dataString1);
			
			//Un cop passat a date podem donar-li format per imprimir-ho com vulguem
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			System.out.println(sdf.format(dateSQLDate));
			
			SimpleDateFormat sdf2 = new SimpleDateFormat("MM/dd/yyyy");
			System.out.println(sdf2.format(dateSQLDate));
			
			//Si partim d'un format d'entrada diferent primer hem de fer un parse
			//per tenir un util.Date
			String dataString2 = "31/12/2023";
			Date dataDate = sdf.parse(dataString2);
			System.out.println(dataDate);
			//I despr�s ho podem imprimir amb el format que vulguem
			System.out.println(sdf2.format(dataDate));
			
			SimpleDateFormat sdf3 = new SimpleDateFormat("dd-MM-yyyy");
			System.out.println(sdf3.format(dataDate));
			
			//Passar de util.Date a sql.Date directament
			java.sql.Date dateSQLConverted = new java.sql.Date(dataDate.getTime());
			//Imprimeix amb el format per defecte de les BD jdbc dd-MM-yyyy
			System.out.println(dateSQLConverted);
			
			//al rev�s �s igual
			Date dateUtilConverted = new Date(dateSQLConverted.getTime());
			//Imprimeix amb el format per defecte del nostre sistema
			System.out.println(dateUtilConverted);
			
			//Tamb� podem canviar el format i fer servir valueOf
			String prova = "9/10/2023";
			SimpleDateFormat sdf4 = new SimpleDateFormat("yyyy-MM-dd");
			java.sql.Date provaDate = java.sql.Date.valueOf(sdf4.format(sdf.parse(prova)));
			System.out.println(provaDate);
			

	}

}
