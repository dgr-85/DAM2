package tutorial;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		String url = "jdbc:mysql://localhost/empleats";
		String user = "cfgs";
		String pwd = "ira491";
		
		try {
			Class.forName("com.mysql.jdbc.Driver"); 
			Connection conexio = DriverManager.getConnection(url,user,pwd);
			
			if(conexio.isValid(0)) {
				System.out.println("Connexió vàlida");
			}
			
			FuncionsJDBC gestor = new FuncionsJDBC();
			//Consulta Departaments
			//gestor.consultaDepartaments(conexio);
			//gestor.consultaEmpleats(conexio);
			gestor.empleatsPerDepartament(conexio);
			
			
			conexio.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

	}

}
