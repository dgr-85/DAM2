package tutorial;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FuncionsJDBC {

	public void consultaDepartaments(Connection conexio){
		//Consulta Departaments
		Statement sentencia;
		try {
			sentencia = conexio.createStatement();
			String sql = "SELECT * FROM departamentos";
			 ResultSet resultat = sentencia.executeQuery(sql);
			 System.out.println("*****Consulta de Departaments*****");
			while (resultat.next()){
				//Accedim a les columnes del resulset per posici� o b� per nom
			 System.out.println("Codi departament: "+resultat.getInt(1)+
			" Nom: "+resultat.getString(2) +  " Ciutat: "+ resultat.getString("loc"));
			} //getString accepta int com a posició de columna o string com a nom de la columna
			System.out.println("\n");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	 
	}
	
	public void consultaEmpleats(Connection conexio){
		Statement sentencia;
		try {
			sentencia = conexio.createStatement();
			String sql = "SELECT * FROM departamentos";
			 ResultSet resultat = sentencia.executeQuery(sql);
			 System.out.println("*****Consulta de Departaments*****");
			while (resultat.next()){
				//Accedim a les columnes del resulset per posici� o b� per nom
			 System.out.println("Codi departament: "+resultat.getInt(1)+
			" Nom: "+resultat.getString(2) +  " Ciutat: "+ resultat.getString("loc"));
			} //getString accepta int com a posició de columna o string com a nom de la columna
			System.out.println("\n");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	 
	}
	
	/*SELECT dnombre,e1.emp_no,e1.apellido,e1.oficio,e2.apellido,e1.salario,e1.comision
	from empleados e1 join empleados e2 on e1.dir=e2.emp_no
	join departamentos on e1.dept_no=departamentos.dept_no*/

		
}
