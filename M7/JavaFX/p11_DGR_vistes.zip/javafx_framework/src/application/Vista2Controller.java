package application;

/**
 * Controller class for the second vista.
 */
public class Vista2Controller {
}