package application;

/**
 * Controller class for the first vista.
 */
public class Vista1Controller {
}