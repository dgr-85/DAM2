package application;

/**
 * Controller class for the third vista.
 */
public class Vista3Controller {

}