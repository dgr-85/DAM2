/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m09.activitats.activitat4;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;

import ioc.dam.m09.activitats.lib.ConsoleInterface;

public class WeekDayClient {
	public static final int FIELD_TYPE_OF_DAY = 0;
	public static final int FIELD_TYPE_OF_MONTH = 1;
	public static final int FIELD_TYPE_OF_YEAR = 2;
	public static final String[] STR_WEEK_DAY = { "Diumenge", "Dilluns", "Dimarts", "Dimecres", "Dijous", "Divendres",
			"Dissabte" };
	ConsoleInterface consoleInterface = new ConsoleInterface();
	InetAddress serverIP;
	int serverPort;
	DatagramSocket socket;
	int attemp = 0;
	int timeOut = 5000;

	public void init(String host, int port) throws SocketException, UnknownHostException {
		serverIP = InetAddress.getByName(host);
		serverPort = port;
		socket = new DatagramSocket();
		String appTitle = "CERCADOR DEL DIA DE LA SETMANA";
		System.out.println(appTitle + System.lineSeparator() + "-".repeat(appTitle.length()));
	}

	public void runClient() throws IOException {
		boolean loopHasFinished = false;
		while (!loopHasFinished) {
			int[] dateToTry = new int[3];
			dateToTry[FIELD_TYPE_OF_DAY] = consoleInterface.readInt("Escriu el número de dia:");
			dateToTry[FIELD_TYPE_OF_MONTH] = consoleInterface.readInt("Escriu el número de mes:");
			dateToTry[FIELD_TYPE_OF_YEAR] = consoleInterface.readInt("Escriu l'any:");
			if (!validateSubmittedDate(dateToTry)) {
				System.out.println("La data introduïda no és vàlida.");
				loopHasFinished = askForNewDate();
			} else {
				byte[] dateInBytes = null;
				try {
					dateInBytes = integersToDateBytes(dateToTry);
				} catch (IOException ex) {
					System.out.println("S'ha produït un error en construir la data.");
				}
				if (dateInBytes != null) {
					DatagramPacket packetToSend = new DatagramPacket(dateInBytes, dateInBytes.length, serverIP,
							serverPort);
					socket.send(packetToSend);
					socket.setSoTimeout(timeOut);

					byte[] dataToReceive = new byte[4];
					DatagramPacket packetToReceive = new DatagramPacket(dataToReceive, dataToReceive.length);

					boolean insistOnSending = true;
					while (insistOnSending) {
						try {
							socket.receive(packetToReceive);
							ByteArrayInputStream arrayIn = new ByteArrayInputStream(dataToReceive);
							DataInputStream dataIn = new DataInputStream(arrayIn);
							System.out.println("Dia de la setmana corresponent: " + STR_WEEK_DAY[dataIn.readInt()]);
							break;
						} catch (SocketTimeoutException ste) {
							System.out.println("S'ha esgotat el temps d'espera.");
							if (!(insistOnSending = askToSendAgain())) {
								loopHasFinished = true;
							}
						}
					}
					loopHasFinished = askForNewDate();
				}
			}
		}
		System.out.println("Programa finalitzat.");
		close();
	}

	public byte[] integersToDateBytes(int[] date) throws IOException {
		byte[] dateInBytes = null;
		ByteArrayOutputStream arrayOut = new ByteArrayOutputStream();
		DataOutputStream dataOut = new DataOutputStream(arrayOut);
		dataOut.writeInt(date[FIELD_TYPE_OF_YEAR]);
		dataOut.writeInt(date[FIELD_TYPE_OF_MONTH]);
		dataOut.writeInt(date[FIELD_TYPE_OF_DAY]);
		dateInBytes = arrayOut.toByteArray();
		dataOut.close();
		return dateInBytes;
	}

	public boolean validateSubmittedDate(int[] date) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			sdf.setLenient(false);
			String strDate = String.valueOf(
					date[FIELD_TYPE_OF_YEAR] + "-" + date[FIELD_TYPE_OF_MONTH] + "-" + date[FIELD_TYPE_OF_DAY]);
			sdf.parse(strDate);
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public boolean askForNewDate() {
		char no = "N".charAt(0);
		return consoleInterface.readYesNo("Vols realitzar una altra operació? (S / N)", no, 2);
	}

	public boolean askToSendAgain() {
		char no = "N".charAt(0);
		return consoleInterface.readYesNo("Vols reintentar-ho? (S / N)", no, 2);
	}

	public void close() {
		if (socket != null && !socket.isClosed()) {
			socket.close();
		}
	}
}
