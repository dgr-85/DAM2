/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m09.activitats.activitat4;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Aquesta classe permet tancar el servidor. Disposa només d'un mètode principal
 * que connecta amb el servidor fent la petició de tancament.
 */
public class ServerCloser {
	public static final int STOP = WeekDayServer.STOP;
	private String address;
	private int port;

	/**
	 * Constructor de la classe. Rep per defecte l'adreça i el port del servidor on
	 * ha de demanar la informació,
	 * 
	 * @param adress és l'adreça IP, domini o nom del host del servidor
	 * @param port   és el port que atent el servidor on cal connectar-se
	 */
	public ServerCloser(String adress, int port) {
		this.address = adress;
		this.port = port;
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		try {
			ServerCloser cli = new ServerCloser("localhost", ServerRunner.PORT);
			cli.closeServer();
		} catch (IOException ex) {
			Logger.getLogger(ServerCloser.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	/**
	 * Envia la comanda al servidor per tal que s'aturi.
	 * 
	 * @throws IOException en cas que no es trobi el servidor.
	 */
	public void closeServer() throws IOException {
		DatagramSocket s = new DatagramSocket();

		InetAddress addr = InetAddress.getByName(address);
		ByteArrayOutputStream arrayOutput = new ByteArrayOutputStream(Integer.SIZE);
		DataOutputStream output = new DataOutputStream(arrayOutput);

		output.writeInt(STOP);
		byte[] sortida = arrayOutput.toByteArray();
		DatagramPacket paquetSortida = new DatagramPacket(sortida, sortida.length, addr, port);
		s.send(paquetSortida);
		s.close();
	}
}
