/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m09.activitats.activitat4;

import java.io.IOException;

public class ClientRunner {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		try {
			WeekDayClient prg = new WeekDayClient();
			prg.init("localhost", ServerRunner.PORT);
			prg.runClient();
		} catch (IOException ex) {
			System.out.println("Error rebent o enviant");
		}
	}
}
