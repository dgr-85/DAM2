/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m09.activitats.activitat4;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServerRunner {
	public static final int PORT = 9994;

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		try {
			WeekDayServer prg = new WeekDayServer();
			prg.init(PORT);
			prg.runServer();
		} catch (IOException ex) {
			Logger.getLogger(ServerRunner.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
