package tcp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.UnknownHostException;

public class Main {
	public static void main(String[] args) {
		HttpClientLittle hcl = new HttpClientLittle();
		String[] uri = null;
		boolean validURI = false;
		while (!validURI) {
			try {
				uri = hcl.getURI();
				validURI = true;
			} catch (Exception e) {
				validURI = false;
			}
		}
		URL url = null;
		try {
			url = new URI(uri[0] + "://" + uri[1]).toURL();
		} catch (MalformedURLException e) {
			System.out.println("URL malformada.");
			e.printStackTrace();
		} catch (URISyntaxException e) {
			System.out.println("URL amb sintaxi incorrecta.");
			e.printStackTrace();
		}
		try (Socket clientSocket = new Socket(url.getHost(), Integer.parseInt(uri[2]))) {
			if (clientSocket != null) {
				OutputStream output = clientSocket.getOutputStream();
				PrintWriter writer = new PrintWriter(output, true);

				writer.println("GET / HTTP/1.1");
				writer.println("Host: " + url.getHost());
				writer.println("User-Agent: Simple Http Client");
				writer.println("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
				writer.println("Accept-Language: en-US");
				writer.println("Connection: keep-alive");
				writer.println();

				InputStream input = clientSocket.getInputStream();

				BufferedReader reader = new BufferedReader(new InputStreamReader(input));

				String line;

				while ((line = reader.readLine()) != null) {
					System.out.println(line);
				}
			}
			hcl.closeScanner();
		} catch (UnknownHostException uhe) {
			System.out.println("Adreça desconeguda: " + uhe.getMessage());
		} catch (Exception e) {
			System.out.println("S'ha produït un error.");
		}
	}
}
