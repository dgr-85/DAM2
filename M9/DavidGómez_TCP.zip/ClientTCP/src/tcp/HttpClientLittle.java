package tcp;

import java.util.Scanner;

public class HttpClientLittle {
	private Scanner sc = new Scanner(System.in);

	public String[] getURI() throws Exception {
		String[] uri = new String[3];
		System.out.println("Protocol (http o https):");
		String protocol = sc.nextLine();
		System.out.println("URL:");
		String url = sc.nextLine();
		if (!protocol.toLowerCase().equals("http") && !protocol.toLowerCase().equals("https") && !protocol.isBlank()) {
			throw new Exception("El format de l'adreça web no és vàlid.");
		}
		if (protocol.isBlank()) {
			protocol = "http";
		}
		uri[0] = protocol;
		uri[1] = url;
		uri[2] = protocol.toLowerCase().equals("http") ? "80" : "443";
		return uri;
	}

	public void closeScanner() {
		sc.close();
	}

}
