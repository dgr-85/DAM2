package cat.institutmarianao.cursa;

public class Cursa {

	public static final int TOTAL_METRES = 1500;
	private static Thread[] corredors;
	private static final String[] NOMS_CORREDORS = { "c1", "c2", "c3" };

	public static void main(String[] args) {

		// TODO crear marcador (únic)
		Marcador marcador = new Marcador(NOMS_CORREDORS.length);

		// TODO crear corredors
		corredors = new Thread[NOMS_CORREDORS.length];

		for (int i = 0; i < NOMS_CORREDORS.length; i++) {
			corredors[i] = new Thread(new Corredor(NOMS_CORREDORS[i], marcador));
			corredors[i].setName(NOMS_CORREDORS[i]);
		}

		// TODO començar cursa (els corredors comencen a córrer) == start();
		c1.start();
		c2.start();
		c3.start();
		// TODO esperar que tots els corredors acabin la carrera == join();

		// TODO pintar marcador
	}
}
