package cat.institutmarianao.cursa;

public class Monitor {
	private int metresRecorreguts;

	public Monitor(int metresRecorreguts) {
		this.metresRecorreguts = metresRecorreguts;
	}

	public synchronized int getDistancia() {
		return metresRecorreguts;
	}

	public synchronized void setDistancia(int segons) {
		metresRecorreguts += segons;
	}
}
