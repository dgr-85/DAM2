package cat.institutmarianao.cursa;

public class Corredor implements Runnable {

	private static final int TOTAL_METRES = 1500;
	private static Monitor[] posicionsFinals;

	@Override
	public void run() {
		try {
			int metresPerSegon = (int) (Math.random() * 3) + 6;
			int distanciaActual = TOTAL_METRES / metresPerSegon;

			Thread.sleep(distanciaActual);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
