package cat.institutmarianao.cotxes;

public class Vehicle {

	private Posicio pos;

	public void desplaçar(Posicio pos) {
		this.pos = pos;
	}

	public Posicio getPos() {
		return pos;
	}

}
