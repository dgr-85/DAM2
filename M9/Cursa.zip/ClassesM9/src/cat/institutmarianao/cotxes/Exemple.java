package cat.institutmarianao.cotxes;

/*public class Exemple {
	public static void main(String[] args) {
		
		Vehicle v=new Cotxe("1234ABC");
		v.desplaçar(new Posicio(4, 2));
	}
}*/
