package cat.institutmarianao.cotxes;

public class Cotxe extends Vehicle{
	private String matricula;

	public Cotxe(String matricula) {
		this.matricula = matricula;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
}
